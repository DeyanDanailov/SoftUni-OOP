﻿

namespace MilitaryElite.Interfaces
{
    public interface ICorps
    {
        string Corps { get; }
    }
}
