﻿

namespace MilitaryElite.Interfaces
{
    public interface ISalary
    {
        decimal Salary {get;}
    }
}
