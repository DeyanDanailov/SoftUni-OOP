﻿

namespace MilitaryElite.Interfaces
{
     public interface IRepair
    {
        string Part { get; }
        int Hours { get; }
    }
}
