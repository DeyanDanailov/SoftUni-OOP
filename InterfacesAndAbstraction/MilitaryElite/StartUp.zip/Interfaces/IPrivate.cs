﻿
namespace MilitaryElite.Interfaces
{
    interface IPrivate
    {
        decimal Salary { get; }
    }
}
