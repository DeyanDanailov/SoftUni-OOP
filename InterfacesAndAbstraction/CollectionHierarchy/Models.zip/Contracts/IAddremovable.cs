﻿

namespace CollectionHierarchy.Contracts
{
    public interface IAddremovable : IAddable
    {
        string Remove();
    }
}
