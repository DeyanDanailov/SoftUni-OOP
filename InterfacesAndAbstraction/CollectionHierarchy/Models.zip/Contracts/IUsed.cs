﻿

namespace CollectionHierarchy.Contracts
{
    public interface IUsed : IAddremovable
    {
        int Used { get; }
    }
}
