﻿
namespace CollectionHierarchy.Contracts
{
	public interface IAddable : IMycolection
	{
		int Add(string item);
	}
}
