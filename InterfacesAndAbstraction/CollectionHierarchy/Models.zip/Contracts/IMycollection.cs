﻿using System;


namespace CollectionHierarchy.Contracts
{
    public interface IMycolection
    {
        string[] Items { get; }

    }
}
