﻿
using System.Linq;
using System;

namespace Telephony
{
    public interface IBrowsable
    {
        string Browse(string website);
       
    }
}
