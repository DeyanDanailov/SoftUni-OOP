﻿

namespace WildFarm.Core
{
    public interface IEngine
    {
        void Run();
    }
}
