﻿

namespace Raiding.Common
{
    public class ExceptionMessages
    {
        public const string INVALID_HERO_EXCEPTION = "Invalid hero!";
    }
}
