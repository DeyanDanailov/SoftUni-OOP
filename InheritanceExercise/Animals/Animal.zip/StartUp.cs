﻿using System;
using System.Collections.Generic;

namespace Animals
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //var typeInput = Console.ReadLine();
            //var allAnimals = new List<Animal>();
            //while (typeInput != "Beast!")
            //{
            //    var propInput = Console.ReadLine().Split();
            //    var name = propInput[0];
            //    var age = int.Parse(propInput[1]);
            //    var gender = propInput[2];
            //    switch (typeInput)
            //    {
            //        case "Dog":
            //            var newDog = new Dog(name, age, gender);
            //            Console.WriteLine(newDog);
            //            allAnimals.Add(newDog);
            //            break;
            //        case "Cat":
            //            var newCat = new Cat(name, age, gender);
            //            Console.WriteLine(newCat);
            //            allAnimals.Add(newCat);
            //            break;
            //        case "Frog":
            //            var newFrog = new Frog(name, age, gender);
            //            Console.WriteLine(newFrog);
            //            allAnimals.Add(newFrog);
            //            break;
            //        case "Kitten":
            //            var newKitten = new Kitten(name, age, gender);
            //            Console.WriteLine(newKitten);
            //            allAnimals.Add(newKitten);
            //            break;
            //        case "Tomcat":
            //            var newTomcat = new Tomcat(name, age, gender);
            //            Console.WriteLine(newTomcat);
            //            allAnimals.Add(newTomcat);
            //            break;
            //        default:
            //            throw new ArgumentException("Invalid input!");
            //    }

            //    typeInput = Console.ReadLine();
            //}
            //Console.WriteLine(String.Join(Environment.NewLine, allAnimals));

            List<Animal> animals = new List<Animal>();

            string command;

            while ((command = Console.ReadLine()) != "Beast!")
            {
                var tokens = Console.ReadLine().Split();

                var name = tokens[0];
                var age = int.Parse(tokens[1]);
                var gender = tokens[2];

                try
                {
                    switch (command)
                    {
                        case "Cat":
                            animals.Add(new Cat(name, age, gender)); break;
                        case "Dog":
                            animals.Add(new Dog(name, age, gender)); break;
                        case "Frog":
                            animals.Add(new Frog(name, age, gender)); break;
                        case "Kitten":
                            animals.Add(new Kitten(name, age)); break;
                        case "Tomcat":
                            animals.Add(new Tomcat(name, age)); break;
                        default:
                            throw new ArgumentException("Invalid input!");
                    }
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            animals.ForEach(Console.WriteLine);


        }
    }
}
