﻿using NUnit.Framework;

[TestFixture]
public class DummyTests
{
    [Test]
    public void DummyShouldLoseHealthAfterAttack()
    {
        //Arrange
        Dummy dummy = new Dummy(20, 20);

        //Act
        dummy.TakeAttack(10);

        //Assert
        Assert.That(dummy.Health.Equals(10));
    }
    [Test]
    public void DeadDummyShouldThrowExceptionIfAttacked()
    {
        //Arrange
        Dummy dummy = new Dummy(0, 20);

        //Assert
        Assert.That(() => dummy.TakeAttack(10), // Act
            Throws.InvalidOperationException
            .With.Message.EqualTo("Dummy is dead."));
       
    }
    [Test]
    public void DeadDummyShouldGiveExperience()
    {
        //Arrange
        Dummy dummy = new Dummy(0, 20);

        //Act
        var exp = dummy.GiveExperience();

        //Assert
        Assert.AreEqual(exp, 20);
    }
    [Test]
    public void AliveDummyCannotGiveExperience()
    {
        //Arrange
        Dummy dummy = new Dummy(20, 20);

        //Assert
        Assert.That(() => dummy.GiveExperience(), //Act
           Throws.InvalidOperationException
           .With.Message.EqualTo("Target is not dead."));
    }
}
