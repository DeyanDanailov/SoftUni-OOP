﻿using System;


namespace EasterRaces.Repositories.Entities
{
    public class DriverRepository <Driver> : Repository<Driver>
    {
    }
}
