﻿

namespace EasterRaces.Repositories.Entities
{
    public class RaceRepository<Race> : Repository<Race>
    {
    }
}
