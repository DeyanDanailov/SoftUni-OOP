﻿namespace Bakery.Utilities.Enums
{
    public enum DrinkType
    {
        Tea = 1,
        Water = 2
    }
}
