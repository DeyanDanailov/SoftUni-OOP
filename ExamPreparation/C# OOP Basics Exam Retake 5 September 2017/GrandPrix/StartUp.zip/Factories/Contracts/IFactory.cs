﻿
namespace GrandPrix.Factories.Contracts
{
    public interface IFactory <T>
    {
        T Produce();
    }
}
