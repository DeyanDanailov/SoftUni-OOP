﻿

using GrandPrix.Models.Cars;

namespace GrandPrix.Models.Drivers
{
    public abstract class Driver : IDriver
    {
        private double speed;
        public Driver(string name, double fuelConsPerKm)
        {
            this.Name = name;
            this.FuelConsumptionPerKm = fuelConsPerKm;
        }
        public string Name { get; private set; }

        public double TotalTime { get; private set; }
        public ICar Car { get; private set; }
        public double FuelConsumptionPerKm { get; private set; }
        public virtual double Speed { get => this.speed;
            private set 
            {
               this.speed = (this.Car.Hp + this.Car.Tyre.Degradation) / this.Car.FuelAmount;
            }
        }
    }
}
