﻿

namespace GrandPrix.Models.Tyres
{
    public abstract class Tyre : ITyre
    {
        private const int INITIAL_TYRE_DEGRADATION = 100;
        public Tyre(string name, double hardness)
        {
            this.Name = name;
            this.Hardness = hardness;
        }
        public string Name { get; private set; }

        public double Hardness { get; private set; }

        public double Degradation => INITIAL_TYRE_DEGRADATION;
    }
}
